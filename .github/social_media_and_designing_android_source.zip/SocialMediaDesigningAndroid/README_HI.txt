SOCIAL MEDIA AND DESIGNING - ANDROID APP PROJECT

यह Android project आपकी वेबसाइट के HTML prototype को Android WebView ऐप में खोलता है।

मोबाइल से APK बनाने का तरीका (GitHub Actions):
1. ZIP को फोन में Extract करें।
2. GitHub पर नया Public या Private repository बनाएं, नाम रखें social-media-and-designing-app।
3. Extract किए हुए SocialMediaDesigningAndroid फ़ोल्डर के अंदर की सभी फाइलें और फ़ोल्डर repository के root में upload करें। .github फ़ोल्डर भी शामिल होना चाहिए।
4. Upload/commit के बाद repository में Actions टैब खोलें।
5. Build Android APK workflow चुनें और Run workflow दबाएं (या main branch पर push के बाद अपने-आप build होगा)।
6. Build पूरा होने पर workflow run खोलें। नीचे Artifacts में social-media-and-designing-debug-apk डाउनलोड करें। ZIP खोलकर app-debug.apk फोन में install करें।
7. Android पूछे तो केवल भरोसेमंद डाउनलोड के लिए इस स्रोत से app install की अनुमति दें।

महत्वपूर्ण:
- यह project APK पहले से compile करके नहीं देता; GitHub Actions क्लाउड में APK बनाएगा।
- GitHub repository में project source upload होगा। Password, OTP, UPI PIN या कोई secret साझा न करें।
- यह ऐप वेबसाइट के मौजूदा HTML prototype को WebView में चलाता है।
- Customer login, admin data और orders अभी browser/local storage demo स्तर पर हैं; secure server/backend नहीं है।
- UPI लिंक भुगतान ऐप खोल सकता है, लेकिन भुगतान की पुष्टि/ऑटो-वेरिफिकेशन नहीं करता।
- वास्तविक ग्राहकों के लिए लॉन्च से पहले backend, secure authentication और payment gateway verification जोड़ें।
